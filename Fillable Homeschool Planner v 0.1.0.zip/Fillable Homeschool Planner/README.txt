Welcome to Fillable Homeschool Planner! (Note: This application is for Windows ONLY!)

To use this application correctly please download the zip folder from the GitHub repsoitory. Once downloaded right click and choose extract all. Extract everyhthing to your C drive. Once that is done click on the shortcut called Fillable Homeschool Planner. Fill out the planner and click the print button to print a .txt file with all the information. 

If you have any bug fixes or questions you can email the developer at:
fellers.ben1@gmail.com

Thanks!