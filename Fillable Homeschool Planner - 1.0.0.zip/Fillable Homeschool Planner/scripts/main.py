# Fillable Homeschool Planner
# v 1.0.0
# Ben Fellers 2020

import os
from tkinter import *
import docx

version = "1.0.0"

if "info.txt" in os.listdir():
    os.system("title Fillable Homeschool Planner v " + version)
    contents = open("info.txt", "r")
    print(contents.read())
    contents.close()
else:
    os.chdir("..")
    os.system("title Fillable Homeschool Planner v " + version)
    contents = open("info.txt", "r")
    print(contents.read())
    contents.close()

class Application(Frame):
    global version
    def __init__(self, master):
        super(Application, self).__init__(master)
        self.grid()
        self.create_widgets()

    def create_widgets(self):
        Label(self,
              text = "Student Name: "
              ).grid(row = 0, column = 0, sticky = W)

        self.name_entry = Entry(self)
        self.name_entry.grid(row = 0, column = 1, sticky = W)


        Label(self,
              text = "Week of: "
              ).grid(row = 1, column = 0, sticky = W)

        self.week_entry = Entry(self)
        self.week_entry.grid(row = 1, column = 1, sticky = W)

        Label(self,
              text = "Comments: "
              ).grid(row = 2, column = 0, sticky = W)

        self.comments_entry = Entry(self)
        self.comments_entry.grid(row = 2, column = 1, sticky = W)

        Label(self,
              text = "Monday"
              ).grid(row = 3, column = 1, sticky = W)

        Label(self,
              text = "Tuesday"
              ).grid(row = 3, column = 2, sticky = W)

        Label(self,
              text = "Wednesday"
              ).grid(row = 3, column = 3, sticky = W)

        Label(self,
              text = "Thursday"
              ).grid(row = 3, column = 4, sticky = W)

        Label(self,
              text = "Friday"
              ).grid(row = 3, column = 5, sticky = W)

        self.subject1 = Entry(self)
        self.subject1.grid(row = 4, column = 0, sticky = W)
        self.subject1.insert(0, "Bible")

        self.subject2 = Entry(self)
        self.subject2.grid(row = 5, column = 0, sticky = W)
        self.subject2.insert(0, "Science")

        self.subject3 = Entry(self)
        self.subject3.grid(row = 6, column = 0, sticky = W)
        self.subject3.insert(0, "Math")

        self.subject4 = Entry(self)
        self.subject4.grid(row = 7, column = 0, sticky = W)
        self.subject4.insert(0, "ELA")

        self.subject5 = Entry(self)
        self.subject5.grid(row = 8, column = 0, sticky = W)
        self.subject5.insert(0, "Notgrass")

        self.subject6 = Entry(self)
        self.subject6.grid(row = 9, column = 0, sticky = W)
        self.subject6.insert(0, "Electives")

        self.subject7 = Entry(self)
        self.subject7.grid(row = 10, column = 0, sticky = W)
        self.subject7.insert(0, "Appointments")

        self.subject8 = Entry(self)
        self.subject8.grid(row = 11, column = 0, sticky = W)
        self.subject8.insert(0, "Field Trips")

        self.subject9 = Entry(self)
        self.subject9.grid(row = 12, column = 0, sticky = W)
        self.subject9.insert(0, "Other")

        self.monday1 = Entry(self)
        self.monday1.grid(row = 4, column = 1, sticky = W)

        self.tuesday1 = Entry(self)
        self.tuesday1.grid(row = 4, column = 2, sticky = W)

        self.wednesday1 = Entry(self)
        self.wednesday1.grid(row = 4, column = 3, sticky = W)

        self.thursday1 = Entry(self)
        self.thursday1.grid(row = 4, column = 4, sticky = W)

        self.friday1 = Entry(self)
        self.friday1.grid(row = 4, column = 5, sticky = W)

        self.monday2 = Entry(self)
        self.monday2.grid(row = 5, column = 1, sticky = W)

        self.tuesday2 = Entry(self)
        self.tuesday2.grid(row = 5, column = 2, sticky = W)

        self.wednesday2 = Entry(self)
        self.wednesday2.grid(row = 5, column = 3, sticky = W)

        self.thursday2 = Entry(self)
        self.thursday2.grid(row = 5, column = 4, sticky = W)

        self.friday2 = Entry(self)
        self.friday2.grid(row = 5, column = 5, sticky = W)

        self.monday3 = Entry(self)
        self.monday3.grid(row = 6, column = 1, sticky = W)

        self.tuesday3 = Entry(self)
        self.tuesday3.grid(row = 6, column = 2, sticky = W)

        self.wednesday3 = Entry(self)
        self.wednesday3.grid(row = 6, column = 3, sticky = W)

        self.thursday3 = Entry(self)
        self.thursday3.grid(row = 6, column = 4, sticky = W)

        self.friday3 = Entry(self)
        self.friday3.grid(row = 6, column = 5, sticky = W)

        self.monday4 = Entry(self)
        self.monday4.grid(row = 7, column = 1, sticky = W)

        self.tuesday4 = Entry(self)
        self.tuesday4.grid(row = 7, column = 2, sticky = W)

        self.wednesday4 = Entry(self)
        self.wednesday4.grid(row = 7, column = 3, sticky = W)

        self.thursday4 = Entry(self)
        self.thursday4.grid(row = 7, column = 4, sticky = W)

        self.friday4 = Entry(self)
        self.friday4.grid(row = 7, column = 5, sticky = W)

        self.monday5 = Entry(self)
        self.monday5.grid(row = 8, column = 1, sticky = W)

        self.tuesday5 = Entry(self)
        self.tuesday5.grid(row = 8, column = 2, sticky = W)

        self.wednesday5 = Entry(self)
        self.wednesday5.grid(row = 8, column = 3, sticky = W)

        self.thursday5 = Entry(self)
        self.thursday5.grid(row = 8, column = 4, sticky = W)

        self.friday5 = Entry(self)
        self.friday5.grid(row = 8, column = 5, sticky = W)

        self.monday6 = Entry(self)
        self.monday6.grid(row = 9, column = 1, sticky = W)

        self.tuesday6 = Entry(self)
        self.tuesday6.grid(row = 9, column = 2, sticky = W)

        self.wednesday6 = Entry(self)
        self.wednesday6.grid(row = 9, column = 3, sticky = W)

        self.thursday6 = Entry(self)
        self.thursday6.grid(row = 9, column = 4, sticky = W)

        self.friday6 = Entry(self)
        self.friday6.grid(row = 9, column = 5, sticky = W)

        self.monday7 = Entry(self)
        self.monday7.grid(row = 10, column = 1, sticky = W)

        self.tuesday7 = Entry(self)
        self.tuesday7.grid(row = 10, column = 2, sticky = W)

        self.wednesday7 = Entry(self)
        self.wednesday7.grid(row = 10, column = 3, sticky = W)

        self.thursday7 = Entry(self)
        self.thursday7.grid(row = 10, column = 4, sticky = W)

        self.friday7 = Entry(self)
        self.friday7.grid(row = 10, column = 5, sticky = W)

        self.monday8 = Entry(self)
        self.monday8.grid(row = 11, column = 1, sticky = W)

        self.tuesday8 = Entry(self)
        self.tuesday8.grid(row = 11, column = 2, sticky = W)

        self.wednesday8 = Entry(self)
        self.wednesday8.grid(row = 11, column = 3, sticky = W)

        self.thursday8 = Entry(self)
        self.thursday8.grid(row = 11, column = 4, sticky = W)

        self.friday8 = Entry(self)
        self.friday8.grid(row = 11, column = 5, sticky = W)

        self.monday9 = Entry(self)
        self.monday9.grid(row = 12, column = 1, sticky = W)

        self.tuesday9 = Entry(self)
        self.tuesday9.grid(row = 12, column = 2, sticky = W)

        self.wednesday9 = Entry(self)
        self.wednesday9.grid(row = 12, column = 3, sticky = W)

        self.thursday9 = Entry(self)
        self.thursday9.grid(row = 12, column = 4, sticky = W)

        self.friday9 = Entry(self)
        self.friday9.grid(row = 12, column = 5, sticky = W)

        Button(self,
               text = "Print",
               command = self.print_planner
               ).grid(row = 16, column = 5, sticky = W)

        Label(self,
              text = ""
              ).grid(row = 13, column = 0, sticky = W)

        Label(self,
              text = "File Name: "      # Seperator label
              ).grid(row = 14, column = 0, sticky = W)

        self.file_name_entry = Entry(self)
        self.file_name_entry.grid(row = 14, column = 1, sticky = W)
        self.file_name_entry.insert(0, ".pf")

        Label(self,
              text = ""         # Seperator label
              ).grid(row = 15, column = 0, sticky = W)

        Button(self,
               text = "Save",
               command = self.save_file
               ).grid(row = 16, column = 0, sticky = W)

        Button(self,
               text = "Load",
               command = self.load_file
               ).grid(row = 16, column = 1, sticky = W)

        Label(self,
              text = ""         # Seperator label
              ).grid(row = 17, column = 0, sticky = W)

        Button(self,
               text = "Clear",
               command = self.clear
               ).grid(row = 16, column = 3, sticky = W)

        Label(self,
              text = "v " + version
              ).grid(row = 18, column = 0, sticky = W)


    def clear(self):
        self.name_entry.delete(0, "end")
        self.week_entry.delete(0, "end")
        self.comments_entry.delete(0, "end")
        self.monday1.delete(0, "end")
        self.monday2.delete(0, "end")
        self.monday3.delete(0, "end")
        self.monday4.delete(0, "end")
        self.monday5.delete(0, "end")
        self.monday6.delete(0, "end")
        self.monday7.delete(0, "end")
        self.monday8.delete(0, "end")
        self.monday9.delete(0, "end")
        self.tuesday1.delete(0, "end")
        self.tuesday2.delete(0, "end")
        self.tuesday3.delete(0, "end")
        self.tuesday4.delete(0, "end")
        self.tuesday5.delete(0, "end")
        self.tuesday6.delete(0, "end")
        self.tuesday7.delete(0, "end")
        self.tuesday8.delete(0, "end")
        self.tuesday9.delete(0, "end")
        self.wednesday1.delete(0, "end")
        self.wednesday2.delete(0, "end")
        self.wednesday3.delete(0, "end")
        self.wednesday4.delete(0, "end")
        self.wednesday5.delete(0, "end")
        self.wednesday6.delete(0, "end")
        self.wednesday7.delete(0, "end")
        self.wednesday8.delete(0, "end")
        self.wednesday9.delete(0, "end")
        self.thursday1.delete(0, "end")
        self.thursday2.delete(0, "end")
        self.thursday3.delete(0, "end")
        self.thursday4.delete(0, "end")
        self.thursday5.delete(0, "end")
        self.thursday6.delete(0, "end")
        self.thursday7.delete(0, "end")
        self.thursday8.delete(0, "end")
        self.thursday9.delete(0, "end")
        self.friday1.delete(0, "end")
        self.friday2.delete(0, "end")
        self.friday3.delete(0, "end")
        self.friday4.delete(0, "end")
        self.friday5.delete(0, "end")
        self.friday6.delete(0, "end")
        self.friday7.delete(0, "end")
        self.friday8.delete(0, "end")
        self.friday9.delete(0, "end")
        self.file_name_entry.delete(0, "end")
        self.file_name_entry.insert(0, ".pf")
        print("Form cleared!")

    def load_file(self):
        if ".pf" in self.file_name_entry.get():
            print("Loading file %s..." % (self.file_name_entry.get()))
            files = os.listdir()
            if self.file_name_entry.get() in files:
                f = open(self.file_name_entry.get(), "r")
                var = f.readline()
                if var.replace("\n", "") == version:
                    var = f.readline()
                    self.name_entry.delete(0, "end")
                    self.name_entry.insert(0, var.replace("\n", ""))
                    print("loaded self.name_entry")
                    var = f.readline()
                    self.week_entry.delete(0, "end")
                    self.week_entry.insert(0, var.replace("\n", ""))
                    print("loaded self.week_entry")
                    var = f.readline()
                    self.comments_entry.delete(0, "end")
                    self.comments_entry.insert(0, var.replace("\n", ""))
                    print("loaded self.comments_entry")
                    var = f.readline()
                    self.subject1.delete(0, "end")
                    self.subject1.insert(0, var.replace("\n", ""))
                    print("loaded self.subject1")
                    var = f.readline()
                    self.subject2.delete(0, "end")
                    self.subject2.insert(0, var.replace("\n", ""))
                    print("loaded self.subject2")
                    var = f.readline()
                    self.subject3.delete(0, "end")
                    self.subject3.insert(0, var.replace("\n", ""))
                    print("loaded self.subject3")
                    var = f.readline()
                    self.subject4.delete(0, "end")
                    self.subject4.insert(0, var.replace("\n", ""))
                    print("loaded self.subject4")
                    var = f.readline()
                    self.subject5.delete(0, "end")
                    self.subject5.insert(0, var.replace("\n", ""))
                    print("loaded self.subject5")
                    var = f.readline()
                    self.subject6.delete(0, "end")
                    self.subject6.insert(0, var.replace("\n", ""))
                    print("loaded self.subject6")
                    var = f.readline()
                    self.subject7.delete(0, "end")
                    self.subject7.insert(0, var.replace("\n", ""))
                    print("loaded self.subject7")
                    var = f.readline()
                    self.subject8.delete(0, "end")
                    self.subject8.insert(0, var.replace("\n", ""))
                    print("loaded self.subject8")
                    var = f.readline()
                    self.subject9.delete(0, "end")
                    self.subject9.insert(0, var.replace("\n", ""))
                    print("loaded self.subject9")
                    var = f.readline()
                    self.monday1.delete(0, "end")
                    self.monday1.insert(0, var.replace("\n", ""))
                    print("loaded self.monday1")
                    var = f.readline()
                    self.monday2.delete(0, "end")
                    self.monday2.insert(0, var.replace("\n", ""))
                    print("loaded self.monday2")
                    var = f.readline()
                    self.monday3.delete(0, "end")
                    self.monday3.insert(0, var.replace("\n", ""))
                    print("loaded self.monday3")
                    var = f.readline()
                    self.monday4.delete(0, "end")
                    self.monday4.insert(0, var.replace("\n", ""))
                    print("loaded self.monday4")
                    var = f.readline()
                    self.monday5.delete(0, "end")
                    self.monday5.insert(0, var.replace("\n", ""))
                    print("loaded self.monday5")
                    var = f.readline()
                    self.monday6.delete(0, "end")
                    self.monday6.insert(0, var.replace("\n", ""))
                    print("loaded self.monday6")
                    var = f.readline()
                    self.monday7.delete(0, "end")
                    self.monday7.insert(0, var.replace("\n", ""))
                    print("loaded self.monday7")
                    var = f.readline()
                    self.monday8.delete(0, "end")
                    self.monday8.insert(0, var.replace("\n", ""))
                    print("loaded self.monday8")
                    var = f.readline()
                    self.monday9.delete(0, "end")
                    self.monday9.insert(0, var.replace("\n", ""))
                    print("loaded self.monday9")
                    var = f.readline()
                    self.tuesday1.delete(0, "end")
                    self.tuesday1.insert(0, var.replace("\n", ""))
                    print("loaded self.tuesday1")
                    var = f.readline()
                    self.tuesday2.delete(0, "end")
                    self.tuesday2.insert(0, var.replace("\n", ""))
                    print("loaded self.tuesday2")
                    var = f.readline()
                    self.tuesday3.delete(0, "end")
                    self.tuesday3.insert(0, var.replace("\n", ""))
                    print("loaded self.tuesday3")
                    var = f.readline()
                    self.tuesday4.delete(0, "end")
                    self.tuesday4.insert(0, var.replace("\n", ""))
                    print("loaded self.tuesday4")
                    var = f.readline()
                    self.tuesday5.delete(0, "end")
                    self.tuesday5.insert(0, var.replace("\n", ""))
                    print("loaded self.tuesday5")
                    var = f.readline()
                    self.tuesday6.delete(0, "end")
                    self.tuesday6.insert(0, var.replace("\n", ""))
                    print("loaded self.tuesday6")
                    var = f.readline()
                    self.tuesday7.delete(0, "end")
                    self.tuesday7.insert(0, var.replace("\n", ""))
                    print("loaded self.tuesday7")
                    var = f.readline()
                    self.tuesday8.delete(0, "end")
                    self.tuesday8.insert(0, var.replace("\n", ""))
                    print("loaded self.tuesday8")
                    var = f.readline()
                    self.tuesday9.delete(0, "end")
                    self.tuesday9.insert(0, var.replace("\n", ""))
                    print("loaded self.tuesday9")
                    var = f.readline()
                    self.wednesday1.delete(0, "end")
                    self.wednesday1.insert(0, var.replace("\n", ""))
                    print("loaded self.wednesday1")
                    var = f.readline()
                    self.wednesday2.delete(0, "end")
                    self.wednesday2.insert(0, var.replace("\n", ""))
                    print("loaded self.wednesday2")
                    var = f.readline()
                    self.wednesday3.delete(0, "end")
                    self.wednesday3.insert(0, var.replace("\n", ""))
                    print("loaded self.wednesday3")
                    var = f.readline()
                    self.wednesday4.delete(0, "end")
                    self.wednesday4.insert(0, var.replace("\n", ""))
                    print("loaded self.wednesday4")
                    var = f.readline()
                    self.wednesday5.delete(0, "end")
                    self.wednesday5.insert(0, var.replace("\n", ""))
                    print("loaded self.wednesday5")
                    var = f.readline()
                    self.wednesday6.delete(0, "end")
                    self.wednesday6.insert(0, var.replace("\n", ""))
                    print("loaded self.wednesday6")
                    var = f.readline()
                    self.wednesday7.delete(0, "end")
                    self.wednesday7.insert(0, var.replace("\n", ""))
                    print("loaded self.wednesday7")
                    var = f.readline()
                    self.wednesday8.delete(0, "end")
                    self.wednesday8.insert(0, var.replace("\n", ""))
                    print("loaded self.wednesday8")
                    var = f.readline()
                    self.wednesday9.delete(0, "end")
                    self.wednesday9.insert(0, var.replace("\n", ""))
                    print("loaded self.wednesday9")
                    var = f.readline()
                    self.thursday1.delete(0, "end")
                    self.thursday1.insert(0, var.replace("\n", ""))
                    print("loaded self.thursday1")
                    var = f.readline()
                    self.thursday2.delete(0, "end")
                    self.thursday2.insert(0, var.replace("\n", ""))
                    print("loaded self.thursday2")
                    var = f.readline()
                    self.thursday3.delete(0, "end")
                    self.thursday3.insert(0, var.replace("\n", ""))
                    print("loaded self.thursday3")
                    var = f.readline()
                    self.thursday4.delete(0, "end")
                    self.thursday4.insert(0, var.replace("\n", ""))
                    print("loaded self.thursday4")
                    var = f.readline()
                    self.thursday5.delete(0, "end")
                    self.thursday5.insert(0, var.replace("\n", ""))
                    print("loaded self.thursday5")
                    var = f.readline()
                    self.thursday6.delete(0, "end")
                    self.thursday6.insert(0, var.replace("\n", ""))
                    print("loaded self.thursday6")
                    var = f.readline()
                    self.thursday7.delete(0, "end")
                    self.thursday7.insert(0, var.replace("\n", ""))
                    print("loaded self.thursday7")
                    var = f.readline()
                    self.thursday8.delete(0, "end")
                    self.thursday8.insert(0, var.replace("\n", ""))
                    print("loaded self.thursday8")
                    var = f.readline()
                    self.thursday9.delete(0, "end")
                    self.thursday9.insert(0, var.replace("\n", ""))
                    print("loaded self.thursday9")
                    var = f.readline()
                    self.friday1.delete(0, "end")
                    self.friday1.insert(0, var.replace("\n", ""))
                    print("loaded self.friday1")
                    var = f.readline()
                    self.friday2.delete(0, "end")
                    self.friday2.insert(0, var.replace("\n", ""))
                    print("loaded self.friday2")
                    var = f.readline()
                    self.friday3.delete(0, "end")
                    self.friday3.insert(0, var.replace("\n", ""))
                    print("loaded self.friday3")
                    var = f.readline()
                    self.friday4.delete(0, "end")
                    self.friday4.insert(0, var.replace("\n", ""))
                    print("loaded self.friday4")
                    var = f.readline()
                    self.friday5.delete(0, "end")
                    self.friday5.insert(0, var.replace("\n", ""))
                    print("loaded self.friday5")
                    var = f.readline()
                    self.friday6.delete(0, "end")
                    self.friday6.insert(0, var.replace("\n", ""))
                    print("loaded self.friday6")
                    var = f.readline()
                    self.friday7.delete(0, "end")
                    self.friday7.insert(0, var.replace("\n", ""))
                    print("loaded self.friday7")
                    var = f.readline()
                    self.friday8.delete(0, "end")
                    self.friday8.insert(0, var.replace("\n", ""))
                    print("loaded self.friday8")
                    var = f.readline()
                    self.friday9.delete(0, "end")
                    self.friday9.insert(0, var.replace("\n", ""))
                    print("loaded self.friday9")
                    f.close()
                    print("Loaded %s..." % (self.file_name_entry.get()))
                    print("Done!")
                else:
                    print("File has been created with a different version of FHP. Cannot open.")
            else:
                print("File not found!")
        else:
            print("File must end with a .pf file extension!")

    def save_file(self):
        if ".pf" in self.file_name_entry.get():
            print("Saving to file: %s..." % (self.file_name_entry.get()))
            f = open(self.file_name_entry.get(), "w")
            f.write(version + "\n")
            f.write(self.name_entry.get() + "\n")
            print("saved self.name_entry")
            f.write(self.week_entry.get() + "\n")
            print("saved self.week_entry")
            f.write(self.comments_entry.get() + "\n")
            print("saved self.comments_entry")
            f.write(self.subject1.get() + "\n")
            print("saved self.subject1")
            f.write(self.subject2.get() + "\n")
            print("saved self.subject2")
            f.write(self.subject3.get() + "\n")
            print("saved self.subject3")
            f.write(self.subject4.get() + "\n")
            print("saved self.subject4")
            f.write(self.subject5.get() + "\n")
            print("saved self.subject5")
            f.write(self.subject6.get() + "\n")
            print("saved self.subject6")
            f.write(self.subject7.get() + "\n")
            print("saved self.subject7")
            f.write(self.subject8.get() + "\n")
            print("saved self.subject8")
            f.write(self.subject9.get() + "\n")
            print("saved self.subject9")
            f.write(self.monday1.get() + "\n")
            print("saved self.monday1")
            f.write(self.monday2.get() + "\n")
            print("saved self.monday2")
            f.write(self.monday3.get() + "\n")
            print("saved self.monday3")
            f.write(self.monday4.get() + "\n")
            print("saved self.monday4")
            f.write(self.monday5.get() + "\n")
            print("saved self.monday5")
            f.write(self.monday6.get() + "\n")
            print("saved self.monday6")
            f.write(self.monday7.get() + "\n")
            print("saved self.monday7")
            f.write(self.monday8.get() + "\n")
            print("saved self.monday8")
            f.write(self.monday9.get() + "\n")
            print("saved self.monday9")
            f.write(self.tuesday1.get() + "\n")
            print("saved self.tuesday1")
            f.write(self.tuesday2.get() + "\n")
            print("saved self.tuesday2")
            f.write(self.tuesday3.get() + "\n")
            print("saved self.tuesday3")
            f.write(self.tuesday4.get() + "\n")
            print("saved self.tuesday4")
            f.write(self.tuesday5.get() + "\n")
            print("saved self.tuesday5")
            f.write(self.tuesday6.get() + "\n")
            print("saved self.tuesday6")
            f.write(self.tuesday7.get() + "\n")
            print("saved self.tuesday7")
            f.write(self.tuesday8.get() + "\n")
            print("saved self.tuesday8")
            f.write(self.tuesday9.get() + "\n")
            print("saved self.tuesday9")
            f.write(self.wednesday1.get() + "\n")
            print("saved self.wednesday1")
            f.write(self.wednesday2.get() + "\n")
            print("saved self.wednesday2")
            f.write(self.wednesday3.get() + "\n")
            print("saved self.wednesday3")
            f.write(self.wednesday4.get() + "\n")
            print("saved self.wednesday4")
            f.write(self.wednesday5.get() + "\n")
            print("saved self.wednesday5")
            f.write(self.wednesday6.get() + "\n")
            print("saved self.wednesday6")
            f.write(self.wednesday7.get() + "\n")
            print("saved self.wednesday7")
            f.write(self.wednesday8.get() + "\n")
            print("saved self.wednesday8")
            f.write(self.wednesday9.get() + "\n")
            print("saved self.wednesday9")
            f.write(self.thursday1.get() + "\n")
            print("saved self.thursday1")
            f.write(self.thursday2.get() + "\n")
            print("saved self.thursday2")
            f.write(self.thursday3.get() + "\n")
            print("saved self.thursday3")
            f.write(self.thursday4.get() + "\n")
            print("saved self.thursday4")
            f.write(self.thursday5.get() + "\n")
            print("saved self.thursday5")
            f.write(self.thursday6.get() + "\n")
            print("saved self.thursday6")
            f.write(self.thursday7.get() + "\n")
            print("saved self.thursday7")
            f.write(self.thursday8.get() + "\n")
            print("saved self.thursday8")
            f.write(self.thursday9.get() + "\n")
            print("saved self.thursday9")
            f.write(self.friday1.get() + "\n")
            print("saved self.friday1")
            f.write(self.friday2.get() + "\n")
            print("saved self.friday2")
            f.write(self.friday3.get() + "\n")
            print("saved self.friday3")
            f.write(self.friday4.get() + "\n")
            print("saved self.friday4")
            f.write(self.friday5.get() + "\n")
            print("saved self.friday5")
            f.write(self.friday6.get() + "\n")
            print("saved self.friday6")
            f.write(self.friday7.get() + "\n")
            print("saved self.friday7")
            f.write(self.friday8.get() + "\n")
            print("saved self.friday8")
            f.write(self.friday9.get() + "\n")
            print("saved self.friday9")
            f.close()
            print("Information saved in %s..." % (self.file_name_entry.get()))
            print("Done!")
        else:
            print("Must be saved with a .pf file extension!")


    def print_planner(self):
        doc = docx.Document()
        doc_para1 = doc.add_paragraph("")
        if self.name_entry.get() != "":
            doc_para1.add_run("Student: ").bold = True
            doc_para1.add_run(self.name_entry.get())
        else:
            print("self.name_entry is null, not writing")


        if self.week_entry.get() != "":
            doc_para1.add_run("\n" + "Week of: ").bold = True
            doc_para1.add_run(self.week_entry.get())
        else:
            print("self.week_entry is null, not writing")

        if self.comments_entry.get() != "":
            doc_para1.add_run("\n" + "Comments: ").bold = True
            doc_para1.add_run(self.comments_entry.get() + "\n")
        else:
            print("self.comments_entry is null, not writing")


        # MONDAY
        doc_para2 = doc.add_paragraph("")
        if self.monday1.get() != "":
            doc_para2.add_run("\nMONDAY\n" + self.subject1.get() + ": ").bold = True
            doc_para2.add_run(self.monday1.get())
        else:
            doc_para2.add_run("\nMONDAY").bold = True
            print("self.monday1 is null, not writing")


        if self.monday2.get() != "":
            doc_para2.add_run("\n" + self.subject2.get() + ": ").bold = True
            doc_para2.add_run(self.monday2.get())
        else:
            print("self.monday2 is null, not writing")

        if self.monday3.get() != "":
            doc_para2.add_run("\n" + self.subject3.get() + ": ").bold = True
            doc_para2.add_run(self.monday3.get())
        else:
            print("self.monday3 is null, not writing")

        if self.monday4.get() != "":
            doc_para2.add_run("\n" + self.subject4.get() + ": ").bold = True
            doc_para2.add_run(self.monday4.get())
        else:
            print("self.monday4 is null, not writing")

        if self.monday5.get() != "":
            doc_para2.add_run("\n" + self.subject5.get() + ": ").bold = True
            doc_para2.add_run(self.monday5.get())
        else:
            print("self.monday5 is null, not writing")

        if self.monday6.get() != "":
            doc_para2.add_run("\n" + self.subject6.get() + ": ").bold = True
            doc_para2.add_run(self.monday6.get())
        else:
            print("self.monday6 is null, not writing")

        if self.monday7.get() != "":
            doc_para2.add_run("\n" + self.subject7.get() + ": ").bold = True
            doc_para2.add_run(self.monday7.get())
        else:
            print("self.monday7 is null, not writing")

        if self.monday8.get() != "":
            doc_para2.add_run("\n" + self.subject8.get() + ": ").bold = True
            doc_para2.add_run(self.monday8.get())
        else:
            print("self.monday8 is null, not writing")

        if self.monday9.get() != "":
            doc_para2.add_run("\n" + self.subject9.get() + ": ").bold = True
            doc_para2.add_run(self.monday9.get())
        else:
            print("self.monday9 is null, not writing")

        # TUESDAY
        doc_para3 = doc.add_paragraph("")
        if self.tuesday1.get() != "":
            doc_para3.add_run("\n\nTUESDAY\n" + self.subject1.get() + ": ").bold = True
            doc_para3.add_run(self.tuesday1.get())
        else:
            doc_para3.add_run("\n\nTUESDAY").bold = True
            print("self.tuesday1 is null, not writing")

        if self.tuesday2.get() != "":
            doc_para3.add_run("\n" + self.subject2.get() + ": ").bold = True
            doc_para3.add_run(self.tuesday2.get())
        else:
            print("self.tuesday2 is null, not writing")

        if self.tuesday3.get() != "":
            doc_para3.add_run("\n" + self.subject3.get() + ": ").bold = True
            doc_para3.add_run(self.tuesday3.get())
        else:
            print("self.tuesday3 is null, not writing")

        if self.tuesday4.get() != "":
            doc_para3.add_run("\n" + self.subject4.get() + ": ").bold = True
            doc_para3.add_run(self.tuesday4.get())
        else:
            print("self.tuesday4 is null, not writing")

        if self.tuesday5.get() != "":
            doc_para3.add_run("\n" + self.subject5.get() + ": ").bold = True
            doc_para3.add_run(self.tuesday5.get())
        else:
            print("self.tuesday5 is null, not writing")

        if self.tuesday6.get() != "":
            doc_para3.add_run("\n" + self.subject6.get() + ": ").bold = True
            doc_para3.add_run(self.tuesday6.get())
        else:
            print("self.tuesday6 is null, not writing")

        if self.tuesday7.get() != "":
            doc_para3.add_run("\n" + self.subject7.get() + ": ").bold = True
            doc_para3.add_run(self.tuesday7.get())
        else:
            print("self.tuesday7 is null, not writing")

        if self.tuesday8.get() != "":
            doc_para3.add_run("\n" + self.subject8.get() + ": ").bold = True
            doc_para3.add_run(self.tuesday8.get())
        else:
            print("self.tuesday8 is null, not writing")

        if self.tuesday9.get() != "":
            doc_para3.add_run("\n" + self.subject9.get() + ": ").bold = True
            doc_para3.add_run(self.tuesday9.get())
        else:
            print("self.tuesday9 is null, not writing")

        # WEDNESDAY
        doc_para4 = doc.add_paragraph("")
        if self.wednesday1.get() != "":
            doc_para4.add_run("\n\nWEDNESDAY\n" + self.subject1.get() + ": ").bold = True
            doc_para4.add_run(self.wednesday1.get())
        else:
            doc_para4.add_run("\n\nWEDNESDAY").bold = True
            print("self.wednesday1 is null, not writing")

        if self.wednesday2.get() != "":
            doc_para4.add_run("\n" + self.subject2.get() + ": ").bold = True
            doc_para4.add_run(self.wednesday2.get())
        else:
            print("self.wednesday2 is null, not writing")

        if self.wednesday3.get() != "":
            doc_para4.add_run("\n" + self.subject3.get() + ": ").bold = True
            doc_para4.add_run(self.wednesday3.get())
        else:
            print("self.wednesday3 is null, not writing")

        if self.wednesday4.get() != "":
            doc_para4.add_run("\n" + self.subject4.get() + ": ").bold = True
            doc_para4.add_run(self.wednesday4.get())
        else:
            print("self.wednesday4 is null, not writing")

        if self.wednesday5.get() != "":
            doc_para4.add_run("\n" + self.subject5.get() + ": ").bold = True
            doc_para4.add_run(self.wednesday5.get())
        else:
            print("self.wednesday5 is null, not writing")

        if self.wednesday6.get() != "":
            doc_para4.add_run("\n" + self.subject6.get() + ": ").bold = True
            doc_para4.add_run(self.wednesday6.get())
        else:
            print("self.wednesday6 is null, not writing")

        if self.wednesday7.get() != "":
            doc_para4.add_run("\n" + self.subject7.get() + ": ").bold = True
            doc_para4.add_run(self.wednesday7.get())
        else:
            print("self.wednesday7 is null, not writing")

        if self.wednesday8.get() != "":
            doc_para4.add_run("\n" + self.subject8.get() + ": ").bold = True
            doc_para4.add_run(self.wednesday8.get())
        else:
            print("self.wednesday8 is null, not writing")

        if self.wednesday9.get() != "":
            doc_para4.add_run("\n" + self.subject9.get() + ": ").bold = True
            doc_para4.add_run(self.wednesday9.get())
        else:
            print("self.wednesday9 is null, not writing")

        # THURSDAY
        doc_para5 = doc.add_paragraph("")
        if self.thursday1.get() != "":
            doc_para5.add_run("\n\nTHURSDAY\n" + self.subject1.get() + ": ").bold = True
            doc_para5.add_run(self.thursday1.get())
        else:
            doc_para5.add_run("\n\nTHURSDAY").bold = True
            print("self.thursday1 is null, not writing")

        if self.thursday2.get() != "":
            doc_para5.add_run("\n" + self.subject2.get() + ": ").bold = True
            doc_para5.add_run(self.thursday2.get())
        else:
            print("self.thursday2 is null, not writing")

        if self.thursday3.get() != "":
            doc_para5.add_run("\n" + self.subject3.get() + ": ").bold = True
            doc_para5.add_run(self.thursday3.get())
        else:
            print("self.thursday3 is null, not writing")

        if self.thursday4.get() != "":
            doc_para5.add_run("\n" + self.subject4.get() + ": ").bold = True
            doc_para5.add_run(self.thursday4.get())
        else:
            print("self.thursday4 is null, not writing")

        if self.thursday5.get() != "":
            doc_para5.add_run("\n" + self.subject5.get() + ": ").bold = True
            doc_para5.add_run(self.thursday5.get())
        else:
            print("self.thursday5 is null, not writing")

        if self.thursday6.get() != "":
            doc_para5.add_run("\n" + self.subject6.get() + ": ").bold = True
            doc_para5.add_run(self.thursday6.get())
        else:
            print("self.thursday6 is null, not writing")

        if self.thursday7.get() != "":
            doc_para5.add_run("\n" + self.subject7.get() + ": ").bold = True
            doc_para5.add_run(self.thursday7.get())
        else:
            print("self.thursday7 is null, not writing")

        if self.thursday8.get() != "":
            doc_para5.add_run("\n" + self.subject8.get() + ": ").bold = True
            doc_para5.add_run(self.thursday8.get())
        else:
            print("self.thursday8 is null, not writing")

        if self.thursday9.get() != "":
            doc_para5.add_run("\n" + self.subject9.get() + ": ").bold = True
            doc_para5.add_run(self.thursday9.get())
        else:
            print("self.thursday9 is null, not writing")

        # FRIDAY
        doc_para6 = doc.add_paragraph("")
        if self.friday1.get() != "":
            doc_para6.add_run("\n\nFRIDAY\n" + self.subject1.get() + ": ").bold = True
            doc_para6.add_run(self.friday1.get())
        else:
            doc_para6.add_run("\n\nFRIDAY").bold = True
            print("self.friday1 is null, not writing")

        if self.friday2.get() != "":
            doc_para6.add_run("\n" + self.subject2.get() + ": ").bold = True
            doc_para6.add_run(self.friday2.get())
        else:
            print("self.friday2 is null, not writing")

        if self.friday3.get() != "":
            doc_para6.add_run("\n" + self.subject3.get() + ": ").bold = True
            doc_para6.add_run(self.friday3.get())
        else:
            print("self.friday3 is null, not writing")

        if self.friday4.get() != "":
            doc_para6.add_run("\n" + self.subject4.get() + ": ").bold = True
            doc_para6.add_run(self.friday4.get())
        else:
            print("self.friday4 is null, not writing")

        if self.friday5.get() != "":
            doc_para6.add_run("\n" + self.subject5.get() + ": ").bold = True
            doc_para6.add_run(self.friday5.get())
        else:
            print("self.friday5 is null, not writing")

        if self.friday6.get() != "":
            doc_para6.add_run("\n" + self.subject6.get() + ": ").bold = True
            doc_para6.add_run(self.friday6.get())
        else:
            print("self.friday6 is null, not writing")

        if self.friday7.get() != "":
            doc_para6.add_run("\n" + self.subject7.get() + ": ").bold = True
            doc_para6.add_run(self.friday7.get())
        else:
            print("self.friday7 is null, not writing")

        if self.friday8.get() != "":
            doc_para6.add_run("\n" + self.subject8.get() + ": ").bold = True
            doc_para6.add_run(self.friday8.get())
        else:
            print("self.friday8 is null, not writing")

        if self.friday9.get() != "":
            doc_para6.add_run("\n" + self.subject9.get() + ": ").bold = True
            doc_para6.add_run(self.friday9.get())
        else:
            print("self.friday9 is null, not writing")
        # End of writing
        doc.save("planner.docx")
        os.startfile("planner.docx", "print")

        


#main
root = Tk()
root.title("Fillable Homeschool Planner")
root.geometry("750x400")
app = Application(root)
root.mainloop()