Welcome to Fillable Homeschool Planner! (Note: This application is for Windows ONLY!)

To use this application correctly please download the zip folder from the GitHub repsoitory. Once downloaded right click and choose extract all. Go into the master folder. Right click on that zip folder and choose extract all. Run Installer.exe and follow the instructions. Then, go to your C:\ drive and run the shortcut called Fillable Homeschool Planner.

If you have any bug fixes or questions you can email the developer at:
fellers.ben1@gmail.com

Thanks!