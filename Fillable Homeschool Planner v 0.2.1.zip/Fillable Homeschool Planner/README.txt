Welcome to Fillable Homeschool Planner! (Note: This application is for Windows ONLY!)

To use this application correctly please download the zip folder from the GitHub repsoitory. Once downloaded right click and choose extract all. Go into the master folder. Right click on that zip folder and choose extract all. Run Installer.bat and follow the instructions. The program will be in C:\Fillable Homeschool Planner.

If you have any bug fixes or questions you can email the developer at:
fellers.ben1@gmail.com

Thanks!