# Fillable Homeschool Planner
# v 0.2.1
# Ben Fellers 2020

import os
from tkinter import *

os.system("title Fillable Homeschool Planner v 0.2.1")
contents = open("info.txt", "r")
print(contents.read())
contents.close()

class Application(Frame):
    def __init__(self, master):
        super(Application, self).__init__(master)
        self.grid()
        self.create_widgets()

    def create_widgets(self):
        Label(self,
              text = "Student Name: "
              ).grid(row = 0, column = 0, sticky = W)

        self.name_entry = Entry(self)
        self.name_entry.grid(row = 0, column = 1, sticky = W)


        Label(self,
              text = "Week of: "
              ).grid(row = 1, column = 0, sticky = W)

        self.week_entry = Entry(self)
        self.week_entry.grid(row = 1, column = 1, sticky = W)

        Label(self,
              text = "Monday"
              ).grid(row = 2, column = 1, sticky = W)

        Label(self,
              text = "Tuesday"
              ).grid(row = 2, column = 2, sticky = W)

        Label(self,
              text = "Wednesday"
              ).grid(row = 2, column = 3, sticky = W)

        Label(self,
              text = "Thursday"
              ).grid(row = 2, column = 4, sticky = W)

        Label(self,
              text = "Friday"
              ).grid(row = 2, column = 5, sticky = W)

        self.subject1 = Entry(self)
        self.subject1.grid(row = 3, column = 0, sticky = W)
        self.subject1.insert(0, "Bible")

        self.subject2 = Entry(self)
        self.subject2.grid(row = 4, column = 0, sticky = W)
        self.subject2.insert(0, "Science")

        self.subject3 = Entry(self)
        self.subject3.grid(row = 5, column = 0, sticky = W)
        self.subject3.insert(0, "Math")

        self.subject4 = Entry(self)
        self.subject4.grid(row = 6, column = 0, sticky = W)
        self.subject4.insert(0, "ELA")

        self.subject5 = Entry(self)
        self.subject5.grid(row = 7, column = 0, sticky = W)
        self.subject5.insert(0, "Notgrass")

        self.subject6 = Entry(self)
        self.subject6.grid(row = 8, column = 0, sticky = W)
        self.subject6.insert(0, "Electives")

        self.subject7 = Entry(self)
        self.subject7.grid(row = 9, column = 0, sticky = W)
        self.subject7.insert(0, "Other")

        self.monday1 = Entry(self)
        self.monday1.grid(row = 3, column = 1, sticky = W)

        self.tuesday1 = Entry(self)
        self.tuesday1.grid(row = 3, column = 2, sticky = W)

        self.wednesday1 = Entry(self)
        self.wednesday1.grid(row = 3, column = 3, sticky = W)

        self.thursday1 = Entry(self)
        self.thursday1.grid(row = 3, column = 4, sticky = W)

        self.friday1 = Entry(self)
        self.friday1.grid(row = 3, column = 5, sticky = W)

        self.monday2 = Entry(self)
        self.monday2.grid(row = 4, column = 1, sticky = W)

        self.tuesday2 = Entry(self)
        self.tuesday2.grid(row = 4, column = 2, sticky = W)

        self.wednesday2 = Entry(self)
        self.wednesday2.grid(row = 4, column = 3, sticky = W)

        self.thursday2 = Entry(self)
        self.thursday2.grid(row = 4, column = 4, sticky = W)

        self.friday2 = Entry(self)
        self.friday2.grid(row = 4, column = 5, sticky = W)

        self.monday3 = Entry(self)
        self.monday3.grid(row = 5, column = 1, sticky = W)

        self.tuesday3 = Entry(self)
        self.tuesday3.grid(row = 5, column = 2, sticky = W)

        self.wednesday3 = Entry(self)
        self.wednesday3.grid(row = 5, column = 3, sticky = W)

        self.thursday3 = Entry(self)
        self.thursday3.grid(row = 5, column = 4, sticky = W)

        self.friday3 = Entry(self)
        self.friday3.grid(row = 5, column = 5, sticky = W)

        self.monday4 = Entry(self)
        self.monday4.grid(row = 6, column = 1, sticky = W)

        self.tuesday4 = Entry(self)
        self.tuesday4.grid(row = 6, column = 2, sticky = W)

        self.wednesday4 = Entry(self)
        self.wednesday4.grid(row = 6, column = 3, sticky = W)

        self.thursday4 = Entry(self)
        self.thursday4.grid(row = 6, column = 4, sticky = W)

        self.friday4 = Entry(self)
        self.friday4.grid(row = 6, column = 5, sticky = W)

        self.monday5 = Entry(self)
        self.monday5.grid(row = 7, column = 1, sticky = W)

        self.tuesday5 = Entry(self)
        self.tuesday5.grid(row = 7, column = 2, sticky = W)

        self.wednesday5 = Entry(self)
        self.wednesday5.grid(row = 7, column = 3, sticky = W)

        self.thursday5 = Entry(self)
        self.thursday5.grid(row = 7, column = 4, sticky = W)

        self.friday5 = Entry(self)
        self.friday5.grid(row = 7, column = 5, sticky = W)

        self.monday6 = Entry(self)
        self.monday6.grid(row = 8, column = 1, sticky = W)

        self.tuesday6 = Entry(self)
        self.tuesday6.grid(row = 8, column = 2, sticky = W)

        self.wednesday6 = Entry(self)
        self.wednesday6.grid(row = 8, column = 3, sticky = W)

        self.thursday6 = Entry(self)
        self.thursday6.grid(row = 8, column = 4, sticky = W)

        self.friday6 = Entry(self)
        self.friday6.grid(row = 8, column = 5, sticky = W)

        self.monday7 = Entry(self)
        self.monday7.grid(row = 9, column = 1, sticky = W)

        self.tuesday7 = Entry(self)
        self.tuesday7.grid(row = 9, column = 2, sticky = W)

        self.wednesday7 = Entry(self)
        self.wednesday7.grid(row = 9, column = 3, sticky = W)

        self.thursday7 = Entry(self)
        self.thursday7.grid(row = 9, column = 4, sticky = W)

        self.friday7 = Entry(self)
        self.friday7.grid(row = 9, column = 5, sticky = W)

        Button(self,
               text = "Print",
               command = self.print_planner
               ).grid(row = 11, column = 0, sticky = W)


    def print_planner(self):
        f = open("planner.txt", "w")
        if self.name_entry.get() != "":
            f.write("\t" * 8 + "Student: %s" % (self.name_entry.get()))
        else:
            print("self.name_entry is null, not writing")


        if self.week_entry.get() != "":
            f.write("\n" + "\t" * 8 + "Week of %s" % (self.week_entry.get()))
        else:
            print("self.week_entry is null, not writing")


        # MONDAY
        if self.monday1.get() != "":
            f.write("\nMONDAY\n" + self.subject1.get() + ": " + self.monday1.get())
        else:
            f.write("\nMONDAY")
            print("self.monday1 is null, not writing")


        if self.monday2.get() != "":
            f.write("\n" + self.subject2.get() + ": " + self.monday2.get())
        else:
            print("self.monday2 is null, not writing")

        if self.monday3.get() != "":
            f.write("\n" + self.subject3.get() + ": " + self.monday3.get())
        else:
            print("self.monday3 is null, not writing")

        if self.monday4.get() != "":
            f.write("\n" + self.subject4.get() + ": " + self.monday4.get())
        else:
            print("self.monday4 is null, not writing")

        if self.monday5.get() != "":
            f.write("\n" + self.subject5.get() + ": " + self.monday5.get())
        else:
            print("self.monday5 is null, not writing")

        if self.monday6.get() != "":
            f.write("\n" + self.subject6.get() + ": " + self.monday6.get())
        else:
            print("self.monday6 is null, not writing")

        if self.monday7.get() != "":
            f.write("\n" + self.subject7.get() + ": " + self.monday7.get())
        else:
            print("self.monday7 is null, not writing")

        # TUESDAY
        if self.tuesday1.get() != "":
            f.write("\n\nTUESDAY\n" + self.subject1.get() + ": " + self.tuesday1.get())
        else:
            f.write("\n\nTUESDAY")
            print("self.tuesday1 is null, not writing")

        if self.tuesday2.get() != "":
            f.write("\n" + self.subject2.get() + ": " + self.tuesday2.get())
        else:
            print("self.tuesday2 is null, not writing")

        if self.tuesday3.get() != "":
            f.write("\n" + self.subject3.get() + ": " + self.tuesday3.get())
        else:
            print("self.tuesday3 is null, not writing")

        if self.tuesday4.get() != "":
            f.write("\n" + self.subject4.get() + ": " + self.tuesday4.get())
        else:
            print("self.tuesday4 is null, not writing")

        if self.tuesday5.get() != "":
            f.write("\n" + self.subject5.get() + ": " + self.tuesday5.get())
        else:
            print("self.tuesday5 is null, not writing")

        if self.tuesday6.get() != "":
            f.write("\n" + self.subject6.get() + ": " + self.tuesday6.get())
        else:
            print("self.tuesday6 is null, not writing")

        if self.tuesday7.get() != "":
            f.write("\n" + self.subject7.get() + ": " + self.tuesday7.get())
        else:
            print("self.tuesday7 is null, not writing")

        # WEDNESDAY
        if self.wednesday1.get() != "":
            f.write("\n\nWEDNESDAY\n" + self.subject1.get() + ": " + self.wednesday1.get())
        else:
            f.write("\n\nWEDNESDAY")
            print("self.wednesday1 is null, not writing")

        if self.wednesday2.get() != "":
            f.write("\n" + self.subject2.get() + ": " + self.wednesday2.get())
        else:
            print("self.wednesday2 is null, not writing")

        if self.wednesday3.get() != "":
            f.write("\n" + self.subject3.get() + ": " + self.wednesday3.get())
        else:
            print("self.wednesday3 is null, not writing")

        if self.wednesday4.get() != "":
            f.write("\n" + self.subject4.get() + ": " + self.wednesday4.get())
        else:
            print("self.wednesday4 is null, not writing")

        if self.wednesday5.get() != "":
            f.write("\n" + self.subject5.get() + ": " + self.wednesday5.get())
        else:
            print("self.wednesday5 is null, not writing")

        if self.wednesday6.get() != "":
            f.write("\n" + self.subject6.get() + ": " + self.wednesday6.get())
        else:
            print("self.wednesday6 is null, not writing")

        if self.wednesday7.get() != "":
            f.write("\n" + self.subject7.get() + ": " + self.wednesday7.get())
        else:
            print("self.wednesday7 is null, not writing")

        # THURSDAY
        if self.thursday1.get() != "":
            f.write("\n\nTHURSDAY\n" + self.subject1.get() + ": " + self.thursday1.get())
        else:
            f.write("\n\nTHURSDAY")
            print("self.thursday1 is null, not writing")

        if self.thursday2.get() != "":
            f.write("\n" + self.subject2.get() + ": " + self.thursday2.get())
        else:
            print("self.thursday2 is null, not writing")

        if self.thursday3.get() != "":
            f.write("\n" + self.subject3.get() + ": " + self.thursday3.get())
        else:
            print("self.thursday3 is null, not writing")

        if self.thursday4.get() != "":
            f.write("\n" + self.subject4.get() + ": " + self.thursday4.get())
        else:
            print("self.thursday4 is null, not writing")

        if self.thursday5.get() != "":
            f.write("\n" + self.subject5.get() + ": " + self.thursday5.get())
        else:
            print("self.thursday5 is null, not writing")

        if self.thursday6.get() != "":
            f.write("\n" + self.subject6.get() + ": " + self.thursday6.get())
        else:
            print("self.thursday6 is null, not writing")

        if self.thursday7.get() != "":
            f.write("\n" + self.subject7.get() + ": " + self.thursday7.get())
        else:
            print("self.thursday7 is null, not writing")

        # FRIDAY
        if self.friday1.get() != "":
            f.write("\n\nFRIDAY\n" + self.subject1.get() + ": " + self.friday1.get())
        else:
            f.write("\n\nFRIDAY")
            print("self.friday1 is null, not writing")

        if self.friday2.get() != "":
            f.write("\n" + self.subject2.get() + ": " + self.friday2.get())
        else:
            print("self.friday2 is null, not writing")

        if self.friday3.get() != "":
            f.write("\n" + self.subject3.get() + ": " + self.friday3.get())
        else:
            print("self.friday3 is null, not writing")

        if self.friday4.get() != "":
            f.write("\n" + self.subject4.get() + ": " + self.friday4.get())
        else:
            print("self.friday4 is null, not writing")

        if self.friday5.get() != "":
            f.write("\n" + self.subject5.get() + ": " + self.friday5.get())
        else:
            print("self.friday5 is null, not writing")

        if self.friday6.get() != "":
            f.write("\n" + self.subject6.get() + ": " + self.friday6.get())
        else:
            print("self.friday6 is null, not writing")

        if self.friday7.get() != "":
            f.write("\n" + self.subject7.get() + ": " + self.friday7.get())
        else:
            print("self.friday7 is null, not writing")
        # End of writing
        f.close()
        os.startfile("planner.txt", "print")

        


#main
root = Tk()
root.title("Fillable Homeschool Planner")
root.geometry("750x300")
app = Application(root)
root.mainloop()