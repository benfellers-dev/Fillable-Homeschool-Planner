Welcome to Fillable Homeschool Planner! (Note: This application is for Windows ONLY!)

To use this application correctly please download the zip folder from the GitHub repsoitory. Once downloaded right click and choose extract all. Go into the master folder. Right click on that zip folder and choose extract all. Go into the folder "Fillable Homeschool Planner" and right click. Choose New -> Shortcut. Type in the path to main.exe (inside Fillable Homeschool Planner -> scripts -> dist). Name the shortcut "Fillable Homeschool Planner" and hit enter. Right click on the shortcut and choose "Pin to taskbar".

If you have any bug fixes or questions you can email the developer at:
fellers.ben1@gmail.com

Thanks!